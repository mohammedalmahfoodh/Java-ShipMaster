Latest 2010-09-16
dcomsec.exe v10
dcomW7.reg
dcomsec.exe.manifest

fab6629bc1a6d4bd986b0241c4c8432f dcomw7.reg
0bb73dc1a6d209a6fc37ca52f98642df dcomsec.exe.manifest
3ba55cfcc0518115fdcfd2f733a5a375 dcomsec.exe

mmc comexp.msc /32
restart master