Norcontrol DC2000 interface.
----------------------------


9600 baud, 8 bit, even parity, 1 stop bit!!! Men anda ASCII-protokoll.

# Command no 22: Temperatur in degree C
# Command no 23: Ullage or Innage in m, corrected for SP.GR., trim, list and offset
# Command no 25: Density
# Command no 26: Volume
# Command no 29: Ullage or Innage uncorrected, i.e. a pressureheight in m fresh water
# Command no 30: Custom data 1
# Command no 31: Custom data 2
# Command no 32: Custom data 3
# Command no 33: Custom data 4
# Command no 34: Ullage or Innage at sensor in m, corrected for SP.GR. and offset
# Command no 83: Send Volume
# Command no 84: Send Weight
# Command no 85: Send Density
# Command no 86: Send custom data 1
# Command no 87: Send custom data 2
# Command no 88: Send custom data 3
# Command no 89: Send custom data 4

030702 Now the progran can also send calculated drafts (df,da) from LOADMASTER
          and calculated TotalRate (to) for Cargo Tanks from LOADMASTER.

Parameter 4 i sdfile.1 skall vara DC2000
Parameter 5 i sdfile.1 �r Request Number till Norcontrol.
Parameter 6 i sdfile.1 �r tanknummer.
Parameter 7 i sdfile.1 anv�ndes ej.

parameter 8 i sdfile.1 (gain) f�r LMC s�tts:
s� att inkommande level omvandlas till meter
s� att inkommande volym omvandlas till m3
s� att inkommande temperatur omvandlas till grader C

parameter 8 i sdfile.1 (gain) f�r SML s�tts:
level: som LMC men dividerat med 1000
volym: som LMC men dividerat med 1000
temperatur: som LMC men dividerat med 10


Tillverkad LMC: 5735
Tillverkad LMC: 5807

Tillverkad SML: 


History:
010720 PR �ndrat s� att parameter 10 styr vad som skickas till LMC.
	Lagt till f�r att skicka ut data.
	Lagt til f�r att anv�nda 2 alternativa serieportar.
030702 PR Changes. Adding sending calculated drafts from LOADMASTER
          and calculated TotalRate for Cargo Tanks from LOADMASTER.
041007 PR Changes. Adding special handling for NORDIC SVENITA. For
          this ship temperature (request 22) is sent with a
          starting T. If there is an extra data line in the
          Norcontrol.ini file then the variable NORDICSVENITA will
          be set to TRUE and the special handling will be made in
          DecodeReceivedString().
          Added display of communication parameters on the debugscreen.
