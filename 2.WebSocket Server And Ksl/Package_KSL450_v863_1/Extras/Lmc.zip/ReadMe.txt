
The contents of this folder coming from \\Fs1\Releases\OnlineActivex\VB6\LMC and is copied to folder \\Fs1\production\system\xxxx\CurrentDelivery\ODP\Levelmaster\LMC by the program ODP.

How to produce a LOADMASTER with online using an Activex interface. (ex. SAABServer 1.3.42.exe).  


1. Start ODP 
2. Set tanks that are not online, to "0"
3. Creates an sdfile.1 (Will be placed in the folder \\Fs1\production\Systems\6763\CurrentDelivery\ODP\Levelmaster\KSL).
4. Edit the Sdfile.1 by deleting all the tanks sat to "0" but were generated anyway.
5. Select protocoll "LMC" 
6. Create KSL files and copies the folder \\Fs1\Releases\OnlineInterface\VB6 to \\Fs1\production\Systems\6763\CurrentDelivery\ODP\Levelmaster\KSL folder)
7.Edit the script regme.cmd
	"%ProgramFiles%\Kockum Sonics\KSL450\XXXX.exe" /regserver
XXXX.exe shall be replaced by the name of the acctual name of the acctual online activex. 
8. Put the  3 files SAABServer 1.3.40.exe, sdfile.1 and Saab.ini in the folder \\Fs1\production\Systems\6763\CurrentDelivery\ODP\Levelmaster\KSL
9. If saab send Ullage corrected (UC), the status-flag for trim and heel measurement must be set in the confXXXX.ksl:

	# Trim Measurement
	1
	#
	# Ref,Trim,Status
	0,0,1
	#
	# Heel Measurement
	1
	#
	# Ref,Heel,Status
	0,0,1


10. Run LDP-program -- This program will now fix the rest.
11. When install "Install Online Configuration and Activex Files" the Activex choosen under point 4 will be registrated.

