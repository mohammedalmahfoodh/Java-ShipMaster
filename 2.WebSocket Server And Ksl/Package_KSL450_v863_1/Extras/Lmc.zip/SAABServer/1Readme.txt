Saab interface.
----------------------------
Specifikation version GKM 95.21

9600 baud, 7 bit, odd parity, 1 stop bit.

Parameter 5 i sdfile.1 �r data typen
Parameter 6 i sdfile.1 �r tanknummer

parameter 8 i sdfile.1 (gain) f�r LMC s�tts:
s� att inkommande level omvandlas till meter
s� att inkommande temperatur omvandlas till grader C
s� att inkommande level rate omvandlas till cm / timme
s� att inkommande densitet omvandlas till t / m3

parameter 8 i sdfile.1 (gain) f�r SML s�tts:
level: som LMC men dividerat med 1000
volym: som LMC men dividerat med 1000
temperatur: som LMC men dividerat med 10

Data ut:
forsta bokstaven i parameter 5 skall vara skriven med liten bokstav
parameter 10 skall skrivas med STORA bokstaver:
" CARGO TANK NO.1 PS" :1:C1P:SA:vV:1:0:0.1:0:VO:1:2:2:
ShipData ut:
parameter 5 skall vara sD
"GM" :115:GM:SA:sD:95:0:0.01:0.0:GM:1:2:95
"BM" :116:BM:SA:sD:94:0:1:0.0:BM:1:2:94
"SF" :117:SF:SA:sD:93:0:1:0.0:SF:1:2:93


Tillverkad LMC: 5487

Tillverkad SML: 

History:
Saab.bas:
'000605 PR Added calculation of levelspeed.
'          In CommunicationOut(), CommunicationIn(): added debugprintout.
'000707 PR In QueryCreate(): changed if-clause.
'000710 PR In QueryCreate(): corrected for sending ship data.
'          Removed extra CRLF at end of question to ask for tank data.
'          In CommunicationSend(): added debugprintout.
'          In CreateStringToSend(): changed TotalRate to GM. Changed two first
'          characters in outputstring for ShipData from "**" to "MA".
'000712 PR In some functions: added lower case "we", "vo" and "vr".
'000815 PR In some functions: added lower case "gm", "bm" and "sf".
online.frm:
'000605 PR In OutPutData() for levelrate: No output if no input,
'          checked on grdColumn.intLR.
'000710 PR In OutPutData() changed TotalRate to GM.
