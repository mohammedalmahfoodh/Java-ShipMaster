MODBUS interface, our end as MASTER.
-----------------------------------------------------------------------

MODBUS RTU (binary!)


9600 baud, 8 bit, no parity, 1 stop bit.

Parameter 5 i sdfile.1 �r Modbus Function code (decimal)
Parameter 6 i sdfile.1 �r Modbus Slave Address (decimal)
Parameter 7 i sdfile.1 �r Modbus address (decimal)

parameter 8 i sdfile.1 (gain) f�r LMC s�tts:
s� att inkommande level omvandlas till meter
s� att inkommande temperatur omvandlas till grader C
s� att inkommande level rate omvandlas till cm / timme
s� att inkommande densitet omvandlas till t / m3

parameter 8 i sdfile.1 (gain) f�r SML s�tts:


Tillverkad X5: 6511

Tillverkad SML: 

History:
modinou.bas:
'060620 PR Started from ModMep and modout.
'060824 PR Added 'WC' watercolumn handling from modta. Changed name to onlineinterface.
'080130 PR Added check on size of meesage in QueryCreate().
